# Maintainers

This delivery package intentionally lists no production authority. Before any public release, the repository must name at least one external maintainer, one security contact, one rights steward and one settlement contact. A single person must not fill all four roles.
