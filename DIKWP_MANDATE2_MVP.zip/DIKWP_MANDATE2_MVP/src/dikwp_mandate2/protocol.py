from __future__ import annotations

import hashlib
import json
from datetime import date
from typing import Any, Dict, Mapping

from .legitimacy import evaluate_dossier
from .models import ActionTicket, MandateLevel


def canonical_hash(value: Mapping[str, Any]) -> str:
    payload = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def compile_action_ticket(dossier: Mapping[str, Any]) -> ActionTicket:
    audit = evaluate_dossier(dossier)
    mandate = dossier.get("mandate", {}) or {}
    if audit.level_cap not in {
        MandateLevel.M3.value,
        MandateLevel.M4.value,
        MandateLevel.M5.value,
        MandateLevel.M6.value,
    }:
        raise ValueError(f"dossier is not eligible for real public action: {audit.decision}")
    action = str(mandate.get("primary_action", "bounded public pilot"))
    operators = [
        str(a.get("id"))
        for a in dossier.get("actors", [])
        if "operator" in set(a.get("roles", []))
    ]
    return ActionTicket(
        ticket_id=f"ticket-{dossier.get('id', 'unknown')}",
        dossier_id=str(dossier.get("id", "unknown")),
        mandate_hash=canonical_hash(mandate),
        action=action,
        operator=operators[0] if operators else "unassigned",
        permitted_by=[str(x) for x in mandate.get("permitted_actions", [])],
        prohibited_actions=[str(x) for x in mandate.get("prohibited_actions", [])],
        human_decision_points=[str(x) for x in mandate.get("human_decision_points", [])],
        rollback_trigger=str((mandate.get("rollback", {}) or {}).get("trigger", "undefined")),
        expiry=str(mandate.get("expiry", "")),
    )


def incident_response(severity: str, dossier: Mapping[str, Any]) -> Dict[str, Any]:
    severity = severity.upper()
    if severity.startswith("S4"):
        action = "KILL_ROUTE_AND_PUBLIC_EMERGENCY_REVIEW"
    elif severity.startswith("S3"):
        action = "AUTOMATIC_HOLD_RESTORE_RIGHTS_AND_INDEPENDENT_REVIEW"
    elif severity.startswith("S2"):
        action = "PAUSE_AFFECTED_COMPONENT_AND_REPAIR"
    elif severity.startswith("S1"):
        action = "REMEDIATE_WITHIN_SERVICE_SLA"
    else:
        action = "LOG_AND_MONITOR"
    return {
        "dossier_id": dossier.get("id"),
        "severity": severity,
        "required_action": action,
        "rights_first": severity.startswith(("S3", "S4")),
        "public_postmortem_required": severity.startswith(("S2", "S3", "S4")),
        "settlement_board_not_operator": True,
        "mandate_hash": canonical_hash(dossier.get("mandate", {}) or {}),
    }


def replication_passport(dossier: Mapping[str, Any], local_node: str, semantic_diff: Mapping[str, Any]) -> Dict[str, Any]:
    audit = evaluate_dossier(dossier)
    if audit.level_cap not in {MandateLevel.M4.value, MandateLevel.M5.value, MandateLevel.M6.value}:
        raise ValueError("replication requires an independently settled M4+ mandate")
    if not semantic_diff:
        raise ValueError("local semantic and institutional differences must be declared")
    return {
        "source_dossier": dossier.get("id"),
        "source_mandate_hash": canonical_hash(dossier.get("mandate", {}) or {}),
        "local_node": local_node,
        "semantic_diff": dict(semantic_diff),
        "requires_local_authorization": True,
        "inherits_evidence_not_authority": True,
        "fork_right": True,
        "status": "LOCAL_MANDATE_REQUIRED",
    }
