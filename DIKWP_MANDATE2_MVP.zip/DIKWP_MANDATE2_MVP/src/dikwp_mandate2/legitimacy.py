from __future__ import annotations

import math
from datetime import date, datetime
from typing import Any, Dict, Iterable, List, Mapping, Sequence, Tuple

from .mesh import transformation_coverage
from .models import AuditResult, Decision, MandateLevel


CRITICAL_ROLES = {
    "proposer",
    "affected_representative",
    "rights_guardian",
    "evidence_steward",
    "operator",
    "security_auditor",
    "fund_steward",
    "settlement_board",
    "ombud",
}

PROHIBITED_ROLE_PAIRS = {
    frozenset(("proposer", "settlement_board")),
    frozenset(("proposer", "rights_guardian")),
    frozenset(("operator", "settlement_board")),
    frozenset(("operator", "security_auditor")),
    frozenset(("fund_steward", "settlement_board")),
    frozenset(("success_metric_owner", "settlement_board")),
    frozenset(("public_authority", "ombud")),
}

REPRESENTATION_BASE = {
    "direct": 1.0,
    "random_panel": 0.9,
    "elected": 0.82,
    "membership_body": 0.75,
    "civil_society": 0.65,
    "rights_guardian": 0.62,
    "expert_proxy": 0.48,
    "notification_only": 0.2,
    "none": 0.0,
}

CONSENT_BASE = {
    "co_authorization": 1.0,
    "consent": 0.9,
    "participation": 0.72,
    "consultation": 0.46,
    "notification": 0.2,
    "none": 0.0,
}


def _clamp(value: float) -> float:
    return max(0.0, min(1.0, float(value)))


def _harmonic(values: Iterable[float]) -> float:
    vals = [_clamp(v) for v in values]
    if not vals or any(v <= 0 for v in vals):
        return 0.0
    return len(vals) / sum(1.0 / v for v in vals)


def _parse_date(value: str) -> date | None:
    try:
        return datetime.strptime(value, "%Y-%m-%d").date()
    except Exception:
        return None


def representation_score(groups: Sequence[Mapping[str, Any]]) -> Tuple[float, List[str]]:
    if not groups:
        return 0.0, ["未登记受影响群体"]
    weighted = 0.0
    denom = 0.0
    warnings: List[str] = []
    for g in groups:
        exposure = _clamp(float(g.get("exposure", 0.0)))
        denom += exposure
        rep = g.get("representation", {}) or {}
        mode = str(rep.get("mode", "none"))
        consent = str(rep.get("consent_level", "none"))
        quality = 0.62 * REPRESENTATION_BASE.get(mode, 0.0) + 0.38 * CONSENT_BASE.get(consent, 0.0)
        if rep.get("independent", False):
            quality += 0.04
        if int(rep.get("participants", 0)) <= 0:
            quality *= 0.55
        if exposure >= 0.75 and consent not in {"participation", "consent", "co_authorization"}:
            warnings.append(f"高暴露群体 {g.get('id', '?')} 尚未获得实质参与或共同授权")
        weighted += exposure * _clamp(quality)
    score = weighted / denom if denom > 0 else 0.0
    return _clamp(score), warnings


def rights_score(rights: Sequence[Mapping[str, Any]], impact_level: str) -> Tuple[float, List[str], List[str]]:
    if not rights:
        return 0.0, ["未声明不可逾越的权利底线"], ["MISSING_RIGHTS_FLOOR"]
    points = 0.0
    hard: List[str] = []
    warnings: List[str] = []
    for r in rights:
        item = 0.0
        if r.get("guardian"):
            item += 0.24
        if r.get("remedy"):
            item += 0.26
        if r.get("monitor"):
            item += 0.20
        if r.get("non_waivable", False):
            item += 0.20
        if r.get("tested", False):
            item += 0.10
        if r.get("violated", False):
            hard.append(f"RIGHT_VIOLATION:{r.get('id', 'unknown')}")
            item = 0.0
        points += _clamp(item)
    score = points / len(rights)
    ids = {str(r.get("id")) for r in rights}
    required = {"human_review", "non_discrimination", "data_portability", "appeal"}
    missing = sorted(required - ids)
    if impact_level == "high" and missing:
        hard.append("MISSING_FUNDAMENTAL_RIGHTS:" + ",".join(missing))
    elif missing:
        warnings.append("建议补充基础权利条款: " + ", ".join(missing))
    return _clamp(score), warnings, hard


def evidence_score(evidence: Sequence[Mapping[str, Any]]) -> Tuple[float, List[str]]:
    if not evidence:
        return 0.0, ["没有证据事件"]
    independent = sum(1 for e in evidence if e.get("independent", False)) / len(evidence)
    confidence = sum(_clamp(float(e.get("confidence", 0.0))) for e in evidence) / len(evidence)
    uncertainty = sum(1 for e in evidence if "uncertainty" in e) / len(evidence)
    provenance = sum(1 for e in evidence if e.get("provenance")) / len(evidence)
    counter = sum(1 for e in evidence if e.get("stance") in {"against", "mixed", "counterfactual"}) / len(evidence)
    score = 0.30 * independent + 0.25 * confidence + 0.18 * uncertainty + 0.17 * provenance + 0.10 * min(1.0, counter * 2.0)
    warnings: List[str] = []
    if independent < 0.34:
        warnings.append("独立证据来源不足")
    if counter == 0:
        warnings.append("未登记反证或竞争解释")
    return _clamp(score), warnings


def option_score(options: Sequence[Mapping[str, Any]]) -> Tuple[float, List[str], List[str]]:
    if not options:
        return 0.0, ["未提出行动选项"], ["NO_OPTIONS"]
    ids = {str(o.get("id", "")) for o in options}
    types = {str(o.get("type", "")) for o in options}
    no_action = "no_action" in ids or "baseline" in types
    alternatives = len(options)
    distributions = sum(1 for o in options if o.get("distributional_analysis")) / len(options)
    reversals = sum(1 for o in options if o.get("reversible", False)) / len(options)
    score = 0.35 * (1.0 if no_action else 0.0) + 0.25 * min(1.0, alternatives / 3.0) + 0.20 * distributions + 0.20 * reversals
    warnings: List[str] = []
    hard: List[str] = []
    if not no_action:
        hard.append("NO_ACTION_BASELINE_MISSING")
    if alternatives < 2:
        warnings.append("行动选项不足，易形成单一路径锁定")
    return _clamp(score), warnings, hard


def reversibility_score(mandate: Mapping[str, Any], operations: Mapping[str, Any]) -> Tuple[float, List[str], List[str]]:
    rollback = mandate.get("rollback", {}) or {}
    start = _parse_date(str(mandate.get("start", "")))
    expiry = _parse_date(str(mandate.get("expiry", "")))
    has_expiry = bool(expiry and start and expiry > start)
    duration_ok = bool(has_expiry and (expiry - start).days <= 366)
    fields = [
        bool(rollback.get("steps")),
        bool(rollback.get("trigger")),
        bool(rollback.get("owner")),
        bool(operations.get("data_export")),
        bool(operations.get("state_restore")),
        bool(mandate.get("automatic_hold_on_severe_incident", False)),
        has_expiry,
        duration_ok,
    ]
    score = sum(1.0 if x else 0.0 for x in fields) / len(fields)
    hard: List[str] = []
    warnings: List[str] = []
    if not has_expiry:
        hard.append("MANDATE_HAS_NO_EXPIRY")
    if not rollback.get("steps") or not rollback.get("trigger"):
        hard.append("ROLLBACK_PATH_MISSING")
    if has_expiry and not duration_ok:
        warnings.append("首次或有限授权超过一年，建议缩短")
    return _clamp(score), warnings, hard


def role_separation_score(actors: Sequence[Mapping[str, Any]], impact_level: str) -> Tuple[float, List[str], List[str]]:
    role_holders: Dict[str, set[str]] = {}
    actor_roles: Dict[str, set[str]] = {}
    for actor in actors:
        actor_id = str(actor.get("id", "unknown"))
        roles = {str(x) for x in actor.get("roles", [])}
        actor_roles[actor_id] = roles
        for role in roles:
            role_holders.setdefault(role, set()).add(actor_id)
    present = len(CRITICAL_ROLES & set(role_holders)) / len(CRITICAL_ROLES)
    conflicts = 0
    conflict_details: List[str] = []
    for actor_id, roles in actor_roles.items():
        for pair in PROHIBITED_ROLE_PAIRS:
            if pair.issubset(roles):
                conflicts += 1
                conflict_details.append(f"{actor_id}:{'+'.join(sorted(pair))}")
    independence = sum(1 for a in actors if a.get("independent", False)) / max(1, len(actors))
    score = 0.58 * present + 0.22 * independence + 0.20 * max(0.0, 1.0 - conflicts / 3.0)
    warnings: List[str] = []
    hard: List[str] = []
    if conflict_details:
        hard.append("PROHIBITED_ROLE_OVERLAP:" + ";".join(conflict_details))
    missing = sorted(CRITICAL_ROLES - set(role_holders))
    if impact_level == "high" and missing:
        hard.append("CRITICAL_ROLES_UNFILLED:" + ",".join(missing))
    elif missing:
        warnings.append("尚未填充角色: " + ", ".join(missing))
    return _clamp(score), warnings, hard


def appeal_score(appeal: Mapping[str, Any]) -> Tuple[float, List[str], List[str]]:
    channels = appeal.get("channels", []) or []
    sla = float(appeal.get("human_review_sla_hours", 9999))
    fields = [
        len(channels) >= 2,
        bool(appeal.get("human_review", False)),
        sla <= 48,
        bool(appeal.get("no_retaliation", False)),
        bool(appeal.get("accessible_offline", False)),
        bool(appeal.get("remedy_catalog")),
        bool(appeal.get("independent_ombud", False)),
    ]
    score = sum(1.0 if x else 0.0 for x in fields) / len(fields)
    warnings: List[str] = []
    hard: List[str] = []
    if not appeal.get("human_review", False):
        hard.append("NO_HUMAN_APPEAL")
    if appeal.get("automated_denial_final", False):
        hard.append("AUTOMATED_RIGHTS_DENIAL")
    if sla > 48:
        warnings.append("涉及基本权益时人工复核时限超过48小时")
    return _clamp(score), warnings, hard


def finance_score(finance: Mapping[str, Any], mandate: Mapping[str, Any]) -> Tuple[float, List[str], List[str]]:
    budget = float(mandate.get("budget", 0.0) or 0.0)
    reserve = float(finance.get("compensation_reserve", 0.0) or 0.0)
    largest = float(finance.get("largest_funder_share", 1.0) or 1.0)
    fields = [
        bool(finance.get("sources_disclosed", False)),
        bool(finance.get("public_ledger", False)),
        bool(finance.get("milestone_escrow", False)),
        bool(finance.get("open_contracting_events", False)),
        bool(finance.get("no_exclusive_lock_in", False)),
        bool(finance.get("exit_and_continuity_clause", False)),
        largest <= 0.5,
        budget <= 0 or reserve / max(budget, 1.0) >= 0.05,
    ]
    score = sum(1.0 if x else 0.0 for x in fields) / len(fields)
    warnings: List[str] = []
    hard: List[str] = []
    if not finance.get("sources_disclosed", False):
        hard.append("UNDISCLOSED_FUNDING")
    if not finance.get("no_exclusive_lock_in", False):
        warnings.append("缺少反锁定条款")
    if largest > 0.5:
        warnings.append("单一出资方占比超过50%，存在议程捕获风险")
    return _clamp(score), warnings, hard


def operations_score(operations: Mapping[str, Any]) -> Tuple[float, List[str]]:
    fields = [
        bool(operations.get("source_tree", False)),
        bool(operations.get("versioned_release", False)),
        bool(operations.get("ci", False)),
        bool(operations.get("security_policy", False)),
        bool(operations.get("sbom", False)),
        bool(operations.get("incident_runbook", False)),
        bool(operations.get("named_operator", False)),
        bool(operations.get("observability", False)),
        bool(operations.get("data_export", False)),
    ]
    score = sum(1.0 if x else 0.0 for x in fields) / len(fields)
    warnings: List[str] = []
    if not operations.get("source_tree", False):
        warnings.append("源码未以可审查目录直接展开")
    if not operations.get("versioned_release", False):
        warnings.append("缺少版本化Release")
    return _clamp(score), warnings


def federation_score(federation: Mapping[str, Any]) -> Tuple[float, List[str]]:
    fields = [
        bool(federation.get("open_export_format", False)),
        bool(federation.get("local_semantic_diff", False)),
        bool(federation.get("local_mandate_required", False)),
        bool(federation.get("fork_right", False)),
        bool(federation.get("compatibility_tests", False)),
        bool(federation.get("independent_settlement_required", False)),
        int(federation.get("external_nodes", 0)) >= 2,
    ]
    score = sum(1.0 if x else 0.0 for x in fields) / len(fields)
    warnings: List[str] = []
    if not federation.get("local_mandate_required", False):
        warnings.append("复制节点没有被要求重新取得本地授权")
    return _clamp(score), warnings


def evaluate_dossier(dossier: Mapping[str, Any], today: date | None = None) -> AuditResult:
    impact = str(dossier.get("impact_level", "medium"))
    warnings: List[str] = []
    hard: List[str] = []

    rep, w = representation_score(dossier.get("affected_groups", []) or [])
    warnings += w
    rights, w, h = rights_score(dossier.get("rights_invariants", []) or [], impact)
    warnings += w; hard += h
    evidence, w = evidence_score(dossier.get("evidence", []) or [])
    warnings += w
    options, w, h = option_score(dossier.get("options", []) or [])
    warnings += w; hard += h
    rev, w, h = reversibility_score(dossier.get("mandate", {}) or {}, dossier.get("operations", {}) or {})
    warnings += w; hard += h
    separation, w, h = role_separation_score(dossier.get("actors", []) or [], impact)
    warnings += w; hard += h
    appeal, w, h = appeal_score(dossier.get("appeal", {}) or {})
    warnings += w; hard += h
    finance, w, h = finance_score(dossier.get("finance", {}) or {}, dossier.get("mandate", {}) or {})
    warnings += w; hard += h
    operations, w = operations_score(dossier.get("operations", {}) or {})
    warnings += w
    federation, w = federation_score(dossier.get("federation", {}) or {})
    warnings += w
    mesh = transformation_coverage(dossier.get("dikwp_network", []) or [])
    if not mesh["network_compatible"]:
        warnings.append("DIKWP变换覆盖和循环不足，可能把语义资源误用为单线层级")

    mandate = dossier.get("mandate", {}) or {}
    if mandate.get("automated_coercive_action", False):
        hard.append("AUTOMATED_COERCIVE_ACTION")
    if not mandate.get("prohibited_actions"):
        hard.append("PROHIBITED_ACTIONS_NOT_DECLARED")
    if not mandate.get("human_decision_points") and impact == "high":
        hard.append("NO_HUMAN_DECISION_POINT")
    if not dossier.get("dissent_packet", {}).get("preserved", False):
        warnings.append("异议包未被永久保存")

    dims = {
        "representation": rep,
        "rights": rights,
        "evidence": evidence,
        "options": options,
        "reversibility": rev,
        "role_separation": separation,
        "appeal_repair": appeal,
        "finance_transparency": finance,
        "operational_readiness": operations,
        "federation_portability": federation,
    }
    floor = min(rep, rights, rev, separation, appeal)
    index = _harmonic(dims.values())

    # Expired mandates cannot authorize action, but remain valid historical records.
    now = today or date.today()
    expiry = _parse_date(str(mandate.get("expiry", "")))
    if expiry and expiry < now:
        hard.append("MANDATE_EXPIRED")

    eligible_level = MandateLevel.M0
    if evidence >= 0.2 and options >= 0.25:
        eligible_level = MandateLevel.M1
    non_expiry_hard = [x for x in hard if x != "MANDATE_EXPIRED"]
    if not non_expiry_hard and rights >= 0.5 and options >= 0.5 and appeal >= 0.45:
        eligible_level = MandateLevel.M2
    if not hard and floor >= 0.65 and index >= 0.66 and evidence >= 0.58 and operations >= 0.55 and finance >= 0.55:
        eligible_level = MandateLevel.M3
    settlement = dossier.get("settlement", {}) or {}
    if (
        eligible_level == MandateLevel.M3
        and settlement.get("independent", False)
        and settlement.get("status") == "passed"
        and not settlement.get("unresolved_severe_incidents", False)
        and index >= 0.72
    ):
        eligible_level = MandateLevel.M4
    if (
        eligible_level == MandateLevel.M4
        and int(dossier.get("federation", {}).get("independent_replications", 0)) >= 2
        and federation >= 0.75
    ):
        eligible_level = MandateLevel.M5
    governance = dossier.get("commons_governance", {}) or {}
    if (
        eligible_level == MandateLevel.M5
        and int(governance.get("external_maintainers", 0)) >= 3
        and governance.get("founder_not_required_for_release", False)
        and governance.get("public_interest_stewardship", False)
        and governance.get("stable_funding", False)
    ):
        eligible_level = MandateLevel.M6

    order = MandateLevel.ordered()
    requested_raw = str(mandate.get("level_requested", MandateLevel.M0.value))
    try:
        requested_level = MandateLevel(requested_raw)
    except ValueError:
        requested_level = MandateLevel.M0
        warnings.append("无法识别请求的授权等级，按M0处理")
    level_cap = order[min(order.index(eligible_level), order.index(requested_level))]
    decision_map = {
        MandateLevel.M0: Decision.BLOCK,
        MandateLevel.M1: Decision.INQUIRY_ONLY,
        MandateLevel.M2: Decision.SHADOW_ELIGIBLE,
        MandateLevel.M3: Decision.PILOT_ELIGIBLE,
        MandateLevel.M4: Decision.LIMITED_ADOPTION_ELIGIBLE,
        MandateLevel.M5: Decision.FEDERATION_ELIGIBLE,
        MandateLevel.M6: Decision.COMMONS_ELIGIBLE,
    }
    decision = decision_map[level_cap]
    if order.index(eligible_level) > order.index(requested_level):
        warnings.append(f"技术与治理条件的资格上限为{eligible_level.value}，但不得超过本次申请的{requested_level.value}")

    required: List[str] = []
    for item in hard:
        required.append("解除硬阻断: " + item)
    weak = sorted(dims.items(), key=lambda kv: kv[1])[:3]
    for key, value in weak:
        if value < 0.72:
            required.append(f"提升 {key}（当前 {value:.2f}）")
    if mesh["coverage"] < 1.0:
        required.append("补齐并实际使用25类DIKWP×DIKWP变换，而非仅在文档中列举")

    return AuditResult(
        dossier_id=str(dossier.get("id", "unknown")),
        requested_level=str(mandate.get("level_requested", MandateLevel.M0.value)),
        decision=decision.value,
        level_cap=level_cap.value,
        eligibility_ceiling=eligible_level.value,
        legitimacy_index=round(index, 4),
        legitimacy_floor=round(floor, 4),
        dimensions={k: round(v, 4) for k, v in dims.items()},
        hard_failures=sorted(set(hard)),
        warnings=sorted(set(warnings)),
        required_actions=required,
        dikwp_coverage=mesh["coverage"],
        dikwp_cycles=mesh["cycles"],
    )
