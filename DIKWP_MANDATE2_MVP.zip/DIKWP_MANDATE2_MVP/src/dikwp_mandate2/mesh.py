from __future__ import annotations

from collections import defaultdict
from typing import Any, Dict, Iterable, List, Mapping, Sequence, Tuple

from .models import DIKWPType


def primitive_transformations() -> List[str]:
    return [f"{a.value}->{b.value}" for a in DIKWPType.all() for b in DIKWPType.all()]


def transformation_coverage(edges: Sequence[Mapping[str, Any]]) -> Dict[str, Any]:
    expected = set(primitive_transformations())
    observed = {
        f"{str(e.get('source', '')).upper()}->{str(e.get('target', '')).upper()}"
        for e in edges
        if str(e.get("source", "")).upper() in {x.value for x in DIKWPType.all()}
        and str(e.get("target", "")).upper() in {x.value for x in DIKWPType.all()}
    }
    adjacency: Dict[str, set[str]] = defaultdict(set)
    for item in observed:
        a, b = item.split("->")
        adjacency[a].add(b)
    cycles = 0
    for a in adjacency:
        for b in adjacency[a]:
            if a == b:
                cycles += 1
            elif a in adjacency.get(b, set()):
                cycles += 1
    cycles //= 2
    return {
        "coverage": round(len(observed & expected) / len(expected), 4),
        "observed": sorted(observed),
        "missing": sorted(expected - observed),
        "cycles": cycles,
        "network_compatible": len(observed & expected) >= 15 and cycles >= 3,
    }


def default_public_action_mesh() -> List[Dict[str, str]]:
    """Return all 25 primitive transformations with public-action interpretations.

    The list is deliberately not a workflow. It is a network alphabet that can be
    traversed in any direction and composed into context-indexed paths.
    """
    meanings = {
        "D->D": "数据的复核、校准、去重和来源修订",
        "D->I": "从观测差异形成关系、分布和异常",
        "D->K": "数据直接挑战或支持因果模型",
        "D->W": "伤害与分配数据改变长期价值判断",
        "D->P": "现实结果迫使行动目的被修改或终止",
        "I->D": "关系假设要求新增可区分观测",
        "I->I": "重构分类、群体边界与影响网络",
        "I->K": "把关联编译为可检验知识主张",
        "I->W": "分配结构暴露公平、权力和生态后果",
        "I->P": "未解决差异形成新的公共问题与行动选项",
        "K->D": "模型生成反证实验和监测需求",
        "K->I": "知识模型改变指标和信息压缩方式",
        "K->K": "竞争模型、复现与知识修订",
        "K->W": "因果知识改变风险、代际与福利判断",
        "K->P": "证据支持、限制或撤销特定公共目的",
        "W->D": "权利与福利要求新增伤害、偏差和排斥观测",
        "W->I": "价值冲突改变群体、尺度和时间窗口划分",
        "W->K": "伦理异议要求替代模型与反事实",
        "W->W": "不同主体和代际价值之间的显式协商",
        "W->P": "不可逾越权利边界限制公共行动目的",
        "P->D": "目的合同选择需要收集和禁止收集的数据",
        "P->I": "行动目的决定哪些差异必须被表达",
        "P->K": "不同目的触发不同知识模型和证据门槛",
        "P->W": "目的接受福利、权力、生态和长期后果审计",
        "P->P": "目的分裂、合并、暂停、撤回、续期和替换",
    }
    rows: List[Dict[str, str]] = []
    for key in primitive_transformations():
        source, target = key.split("->")
        rows.append({"source": source, "target": target, "meaning": meanings[key]})
    return rows
