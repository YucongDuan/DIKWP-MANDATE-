from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from typing import Any, Dict, List

from .dashboard import render_dashboard
from .ecosystem import audit_ecosystem
from .ledger import HashLedger
from .legitimacy import evaluate_dossier
from .mesh import default_public_action_mesh
from .outputs import write_csv, write_json
from .protocol import compile_action_ticket, incident_response
from .simulation import simulate


def _load(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def _manifest(root: Path) -> List[str]:
    lines: List[str] = []
    for path in sorted(p for p in root.rglob("*") if p.is_file() and p.name != "MANIFEST.sha256"):
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        lines.append(f"{digest}  {path.relative_to(root).as_posix()}")
    (root / "MANIFEST.sha256").write_text("\n".join(lines) + "\n", encoding="utf-8")
    return lines


def demo(root: Path, trials: int, seed: int) -> Dict[str, Any]:
    out = root / "outputs"; out.mkdir(parents=True, exist_ok=True)
    repos = _load(root / "data" / "github_ecosystem_sample.json")
    ecosystem = audit_ecosystem(repos)
    example_paths = [
        root / "examples" / "community_ai_transition_pilot.json",
        root / "examples" / "public_benefits_ai_triage_blocked.json",
        root / "examples" / "agent_assurance_shadow.json",
    ]
    dossier_audits = []
    ledger = HashLedger()
    for path in example_paths:
        dossier = _load(path)
        audit = evaluate_dossier(dossier, today=__import__("datetime").date(2026, 7, 17))
        dossier_audits.append({"title": dossier["title"], "audit": audit.to_dict()})
        ledger.append("DOSSIER_AUDITED", {"dossier_id": dossier["id"], "decision": audit.decision, "level_cap": audit.level_cap})
        if audit.decision in {"PILOT_ELIGIBLE", "LIMITED_ADOPTION_ELIGIBLE", "FEDERATION_ELIGIBLE", "COMMONS_ELIGIBLE"}:
            ticket = compile_action_ticket(dossier)
            ledger.append("ACTION_TICKET_PROPOSED", ticket.to_dict())
    sim = simulate(trials=trials, seed=seed)
    summary = {
        "system": "DIKWP-MANDATE²",
        "version": "0.1.0",
        "ecosystem_audit": ecosystem,
        "dossier_audits": dossier_audits,
        "simulation": sim,
        "dikwp_mesh": default_public_action_mesh(),
        "ledger_valid": ledger.verify(),
        "disclaimer": "Synthetic and advisory only; no real public authority is granted.",
    }
    write_json(out / "mandate2_snapshot.json", summary)
    write_json(out / "ecosystem_audit.json", ecosystem)
    write_json(out / "dossier_audits.json", dossier_audits)
    write_json(out / "strategy_simulation.json", sim)
    write_csv(out / "strategy_simulation.csv", sim["strategies"])
    ledger.write_jsonl(out / "public_action_ledger.jsonl")
    render_dashboard(summary, out / "dashboard.html")
    run_proof = {
        "command": f"PYTHONPATH=src python -m dikwp_mandate2.cli demo --root . --trials {trials} --seed {seed}",
        "ledger_valid": ledger.verify(),
        "sample_size": ecosystem["sample_size"],
        "audited_dossiers": len(dossier_audits),
        "synthetic_trials": sim["trials"],
    }
    write_json(root / "RUN_PROOF.json", run_proof)
    _manifest(root)
    return summary


def main() -> None:
    parser = argparse.ArgumentParser(prog="dikwp-mandate2")
    sub = parser.add_subparsers(dest="cmd", required=True)
    p_demo = sub.add_parser("demo")
    p_demo.add_argument("--root", default=".")
    p_demo.add_argument("--trials", type=int, default=15000)
    p_demo.add_argument("--seed", type=int, default=7172026)
    p_eval = sub.add_parser("evaluate")
    p_eval.add_argument("file")
    p_eval.add_argument("--out")
    p_inc = sub.add_parser("incident")
    p_inc.add_argument("file")
    p_inc.add_argument("--severity", required=True)
    args = parser.parse_args()
    if args.cmd == "demo":
        summary = demo(Path(args.root).resolve(), args.trials, args.seed)
        print(json.dumps({"ok": True, "dashboard": "outputs/dashboard.html", "ledger_valid": summary["ledger_valid"]}, ensure_ascii=False))
    elif args.cmd == "evaluate":
        dossier = _load(Path(args.file))
        audit = evaluate_dossier(dossier)
        text = json.dumps(audit.to_dict(), ensure_ascii=False, indent=2)
        if args.out:
            Path(args.out).write_text(text, encoding="utf-8")
        print(text)
    else:
        dossier = _load(Path(args.file))
        print(json.dumps(incident_response(args.severity, dossier), ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
