from __future__ import annotations

import html
import json
from pathlib import Path
from typing import Any, Mapping, Sequence


def _bar(value: float) -> str:
    pct = max(0.0, min(100.0, 100.0 * float(value)))
    return f'<div class="bar"><span style="width:{pct:.1f}%"></span></div>'


def render_dashboard(summary: Mapping[str, Any], path: str | Path) -> None:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    eco = summary["ecosystem_audit"]
    audits = summary["dossier_audits"]
    sim = summary["simulation"]
    audits_html = "".join(
        f"<article><h3>{html.escape(a['title'])}</h3><p><b>{a['audit']['decision']}</b> · authorized cap {a['audit']['level_cap']} · eligibility {a['audit']['eligibility_ceiling']}</p>"
        f"<p>Legitimacy {a['audit']['legitimacy_index']:.2f}{_bar(a['audit']['legitimacy_index'])}"
        f"Rights {a['audit']['dimensions']['rights']:.2f}{_bar(a['audit']['dimensions']['rights'])}"
        f"Representation {a['audit']['dimensions']['representation']:.2f}{_bar(a['audit']['dimensions']['representation'])}</p>"
        f"<p class='small'>Hard gates: {html.escape(', '.join(a['audit']['hard_failures']) or 'none')}</p></article>"
        for a in audits
    )
    sim_rows = "".join(
        f"<tr><td>{html.escape(r['strategy'])}</td><td>{r['median_impact']:.1f}</td><td>{r['median_nodes_24m']}</td>"
        f"<td>{r['mean_rights_incident_risk']:.1%}</td><td>{r['mean_capture_risk']:.1%}</td>"
        f"<td>{r['survival_24m_probability']:.1%}</td><td>{r['median_months_to_first_pilot']:.1f}</td></tr>"
        for r in sim["strategies"]
    )
    missing = "".join(f"<li>{html.escape(x)}</li>" for x in eco["missing_transaction_layer"])
    doc = f"""<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>DIKWP-MANDATE²</title><style>
:root{{--bg:#f3f5f7;--card:#fff;--ink:#17212b;--muted:#5b6571;--line:#d8dde4;--accent:#2e5b78;--danger:#8d2f2f}}
*{{box-sizing:border-box}}body{{margin:0;background:var(--bg);color:var(--ink);font-family:system-ui,-apple-system,"Segoe UI","Noto Sans CJK SC",sans-serif;line-height:1.55}}
header{{padding:34px 5vw;background:#132936;color:white}}main{{max-width:1180px;margin:auto;padding:24px}}h1{{margin:0 0 8px}}h2{{margin-top:30px}}
.grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(245px,1fr));gap:14px}}article,.panel{{background:var(--card);border:1px solid var(--line);border-radius:12px;padding:16px;box-shadow:0 2px 8px rgba(0,0,0,.035)}}
.metric{{font-size:2rem;font-weight:760}}.small{{font-size:.9rem;color:var(--muted)}}.bar{{height:8px;border-radius:8px;background:#e7ebef;overflow:hidden;margin:4px 0 9px}}.bar span{{display:block;height:100%;background:var(--accent)}}
table{{border-collapse:collapse;width:100%;background:white}}th,td{{border:1px solid var(--line);padding:9px;text-align:left}}th{{background:#edf1f4}}code{{background:#edf1f4;padding:2px 5px;border-radius:4px}}.notice{{border-left:4px solid var(--danger);background:white;padding:12px 15px}}footer{{text-align:center;color:var(--muted);padding:28px}}
</style></head><body><header><h1>DIKWP-MANDATE²</h1><p>公共行动授权、可逆试点、独立结算与联邦复制协议 · 离线机制演示</p></header><main>
<section class="grid"><div class="panel"><div class="metric">{eco['sample_size']}</div><div>GitHub代表性仓库样本</div></div><div class="panel"><div class="metric">{eco['average_maturity']:.2f}</div><div>开放维护成熟度启发式均值</div></div><div class="panel"><div class="metric">{eco['release_share']:.1%}</div><div>样本Release覆盖</div></div><div class="panel"><div class="metric">{eco['external_interaction_signal_share']:.1%}</div><div>外部Issue/Fork信号</div></div></section>
<h2>缺失的公共行动交易层</h2><div class="panel"><ul>{missing}</ul></div>
<h2>三个示例公共行动审计</h2><section class="grid">{audits_html}</section>
<h2>开源战略的合成压力测试</h2><div class="panel"><table><thead><tr><th>战略</th><th>中位影响</th><th>24月节点</th><th>权利事件风险</th><th>捕获风险</th><th>24月存续</th><th>首次试点（月）</th></tr></thead><tbody>{sim_rows}</tbody></table></div>
<p class="notice">本原型不授予任何现实公共权力，不执行支付、行政决定、福利拒付、身份判断或网络部署。所有分数和概率均为用于测试协议结构的合成或启发式结果。真实授权必须来自适用法律、受影响群体、独立审查与明确责任主体。</p>
<h2>可复现命令</h2><div class="panel"><code>PYTHONPATH=src python -m dikwp_mandate2.cli demo --root . --trials 15000 --seed 7172026</code></div>
</main><footer>DIKWP-MANDATE² · Apache-2.0 reference implementation</footer></body></html>"""
    p.write_text(doc, encoding="utf-8")
