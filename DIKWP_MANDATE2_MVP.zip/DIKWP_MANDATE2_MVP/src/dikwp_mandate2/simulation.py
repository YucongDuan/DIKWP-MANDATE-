from __future__ import annotations

import random
from statistics import median
from typing import Any, Dict, List


STRATEGIES = {
    "继续仓库扩张": {
        "trust": 0.22, "adoption": 0.18, "capture": 0.20, "rights": 0.17, "maintainers": 0.12, "fragmentation": 0.82, "speed": 0.86,
    },
    "中心化标准与认证": {
        "trust": 0.57, "adoption": 0.53, "capture": 0.62, "rights": 0.55, "maintainers": 0.42, "fragmentation": 0.38, "speed": 0.58,
    },
    "平台伙伴快速分发": {
        "trust": 0.44, "adoption": 0.75, "capture": 0.79, "rights": 0.39, "maintainers": 0.33, "fragmentation": 0.31, "speed": 0.80,
    },
    "MANDATE联邦公共行动": {
        "trust": 0.76, "adoption": 0.68, "capture": 0.23, "rights": 0.81, "maintainers": 0.72, "fragmentation": 0.24, "speed": 0.46,
    },
}


def _bounded(rng: random.Random, mean: float, spread: float = 0.13) -> float:
    return max(0.0, min(1.0, rng.gauss(mean, spread)))


def simulate(trials: int = 15000, seed: int = 7172026) -> Dict[str, Any]:
    rng = random.Random(seed)
    rows: List[Dict[str, Any]] = []
    per = max(1, trials // len(STRATEGIES))
    for name, p in STRATEGIES.items():
        impacts: List[float] = []
        nodes: List[int] = []
        incidents: List[float] = []
        survival: List[int] = []
        capture: List[float] = []
        time_to_pilot: List[float] = []
        for _ in range(per):
            trust = _bounded(rng, p["trust"])
            adoption = _bounded(rng, p["adoption"])
            cap = _bounded(rng, p["capture"], 0.11)
            rights = _bounded(rng, p["rights"])
            maintainers = _bounded(rng, p["maintainers"])
            frag = _bounded(rng, p["fragmentation"])
            speed = _bounded(rng, p["speed"], 0.10)
            external_shock = max(0.0, min(1.0, rng.betavariate(2.2, 4.5)))
            impact = 100 * (
                0.24 * trust + 0.24 * adoption + 0.20 * rights + 0.16 * maintainers
                + 0.10 * (1 - cap) + 0.06 * (1 - frag)
            ) * (0.90 + 0.20 * external_shock)
            n_nodes = max(0, int(round(1 + 18 * adoption * maintainers * trust * (1 - 0.45 * frag))))
            incident_rate = max(0.0, min(1.0, 0.42 * (1 - rights) + 0.28 * cap + 0.18 * speed - 0.12 * trust))
            survived = int(rng.random() < max(0.0, min(1.0, 0.15 + 0.36 * trust + 0.26 * maintainers + 0.16 * (1 - cap) + 0.12 * adoption)))
            months = max(1.0, 3.0 + 18.0 * (1 - speed) + rng.gauss(0, 2.0))
            impacts.append(impact)
            nodes.append(n_nodes)
            incidents.append(incident_rate)
            survival.append(survived)
            capture.append(cap)
            time_to_pilot.append(months)
        rows.append({
            "strategy": name,
            "median_impact": round(median(impacts), 2),
            "median_nodes_24m": int(median(nodes)),
            "mean_rights_incident_risk": round(sum(incidents) / len(incidents), 4),
            "survival_24m_probability": round(sum(survival) / len(survival), 4),
            "mean_capture_risk": round(sum(capture) / len(capture), 4),
            "median_months_to_first_pilot": round(median(time_to_pilot), 1),
        })
    rows.sort(key=lambda x: x["median_impact"], reverse=True)
    return {"trials": per * len(STRATEGIES), "seed": seed, "strategies": rows, "synthetic": True}
