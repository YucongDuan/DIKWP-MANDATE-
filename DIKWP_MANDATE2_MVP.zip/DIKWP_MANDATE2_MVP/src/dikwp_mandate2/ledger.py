from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Iterable, List, Mapping


def _hash_payload(payload: Mapping[str, Any]) -> str:
    raw = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


class HashLedger:
    def __init__(self) -> None:
        self.entries: List[Dict[str, Any]] = []

    def append(self, event_type: str, payload: Mapping[str, Any]) -> Dict[str, Any]:
        previous = self.entries[-1]["entry_hash"] if self.entries else "GENESIS"
        base = {
            "index": len(self.entries),
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "event_type": event_type,
            "payload": dict(payload),
            "previous_hash": previous,
        }
        base["entry_hash"] = _hash_payload(base)
        self.entries.append(base)
        return base

    def verify(self) -> bool:
        previous = "GENESIS"
        for i, entry in enumerate(self.entries):
            if entry.get("index") != i or entry.get("previous_hash") != previous:
                return False
            clone = {k: v for k, v in entry.items() if k != "entry_hash"}
            if _hash_payload(clone) != entry.get("entry_hash"):
                return False
            previous = str(entry.get("entry_hash"))
        return True

    def write_jsonl(self, path: str | Path) -> None:
        p = Path(path)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text("".join(json.dumps(e, ensure_ascii=False, sort_keys=True) + "\n" for e in self.entries), encoding="utf-8")
