"""DIKWP-MANDATE² public-action legitimacy and federation protocol."""

__version__ = "0.1.0"
