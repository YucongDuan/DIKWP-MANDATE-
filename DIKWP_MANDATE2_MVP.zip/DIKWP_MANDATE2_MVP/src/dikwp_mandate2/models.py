from __future__ import annotations

from dataclasses import asdict, dataclass, field
from enum import Enum
from typing import Any, Dict, List, Mapping


class DIKWPType(str, Enum):
    D = "D"
    I = "I"
    K = "K"
    W = "W"
    P = "P"

    @classmethod
    def all(cls) -> List["DIKWPType"]:
        return [cls.D, cls.I, cls.K, cls.W, cls.P]


class MandateLevel(str, Enum):
    M0 = "M0_CONCEPT"
    M1 = "M1_INQUIRY"
    M2 = "M2_SHADOW"
    M3 = "M3_BOUNDED_PILOT"
    M4 = "M4_LIMITED_ADOPTION"
    M5 = "M5_FEDERATED_REPLICATION"
    M6 = "M6_COMMONS_INFRASTRUCTURE"

    @classmethod
    def ordered(cls) -> List["MandateLevel"]:
        return [cls.M0, cls.M1, cls.M2, cls.M3, cls.M4, cls.M5, cls.M6]


class Decision(str, Enum):
    BLOCK = "BLOCK"
    INQUIRY_ONLY = "INQUIRY_ONLY"
    SHADOW_ELIGIBLE = "SHADOW_ELIGIBLE"
    PILOT_ELIGIBLE = "PILOT_ELIGIBLE"
    LIMITED_ADOPTION_ELIGIBLE = "LIMITED_ADOPTION_ELIGIBLE"
    FEDERATION_ELIGIBLE = "FEDERATION_ELIGIBLE"
    COMMONS_ELIGIBLE = "COMMONS_ELIGIBLE"


class IncidentSeverity(str, Enum):
    S0 = "S0_OBSERVATION"
    S1 = "S1_SERVICE_DEGRADATION"
    S2 = "S2_MATERIAL_HARM"
    S3 = "S3_RIGHTS_OR_SAFETY_HARM"
    S4 = "S4_CATASTROPHIC_OR_SYSTEMIC"


@dataclass(slots=True)
class AuditResult:
    dossier_id: str
    requested_level: str
    decision: str
    level_cap: str
    eligibility_ceiling: str
    legitimacy_index: float
    legitimacy_floor: float
    dimensions: Dict[str, float]
    hard_failures: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    required_actions: List[str] = field(default_factory=list)
    dikwp_coverage: float = 0.0
    dikwp_cycles: int = 0

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass(slots=True)
class ActionTicket:
    ticket_id: str
    dossier_id: str
    mandate_hash: str
    action: str
    operator: str
    permitted_by: List[str]
    prohibited_actions: List[str]
    human_decision_points: List[str]
    rollback_trigger: str
    expiry: str
    state: str = "PROPOSED_NOT_ACTIVATED"

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass(slots=True)
class LedgerEntry:
    index: int
    timestamp: str
    event_type: str
    payload: Dict[str, Any]
    previous_hash: str
    entry_hash: str

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)
