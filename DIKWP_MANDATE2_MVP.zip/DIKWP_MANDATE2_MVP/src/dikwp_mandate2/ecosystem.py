from __future__ import annotations

from collections import Counter
from typing import Any, Dict, Mapping, Sequence


def repo_maturity(repo: Mapping[str, Any]) -> float:
    fields = [
        repo.get("has_source_tree", False),
        repo.get("has_tests", False),
        repo.get("has_ci", False),
        repo.get("has_release", False),
        repo.get("has_security_policy", False),
        repo.get("has_contributing", False),
        repo.get("has_code_of_conduct", False),
        int(repo.get("forks", 0)) > 0,
        int(repo.get("open_issues", 0)) > 0,
    ]
    return round(sum(1.0 if x else 0.0 for x in fields) / len(fields), 4)


def audit_ecosystem(repos: Sequence[Mapping[str, Any]]) -> Dict[str, Any]:
    tag_counts = Counter()
    lane_counts = Counter()
    for repo in repos:
        tags = list(repo.get("tags", []))
        if tags:
            lane_counts[tags[0]] += 1
        for tag in tags[1:]:
            tag_counts[tag] += 1
    maturity = [repo_maturity(r) for r in repos]
    zip_delivery = sum(1 for r in repos if not r.get("has_source_tree", False))
    releases = sum(1 for r in repos if r.get("has_release", False))
    external_signals = sum(1 for r in repos if int(r.get("forks", 0)) > 0 or int(r.get("open_issues", 0)) > 0)
    return {
        "sample_size": len(repos),
        "lane_counts": dict(lane_counts),
        "domain_counts": dict(tag_counts.most_common()),
        "average_maturity": round(sum(maturity) / max(1, len(maturity)), 4),
        "zip_or_non_source_tree_share": round(zip_delivery / max(1, len(repos)), 4),
        "release_share": round(releases / max(1, len(repos)), 4),
        "external_interaction_signal_share": round(external_signals / max(1, len(repos)), 4),
        "strategic_strengths": [
            "语义网络与概念空间",
            "目的、权限与智能体保障",
            "人工意识、生命与跨基质研究",
            "预测、社会韧性与公共价值",
            "教育、医疗、金融和交通等场景化探索",
            "资源路由、标准、来源归属与生态收束意识",
        ],
        "missing_transaction_layer": [
            "受影响群体如何获得真实代表与共同授权",
            "公共行动的权限、期限、预算和禁止项如何被机器可读地限定",
            "政府、大学、社区、企业与开源维护者之间如何分权",
            "申诉、补偿、停机、回滚和日落如何成为协议硬条件",
            "试点结论如何由独立主体结算而不是由提案者自证",
            "一个成功试点如何在不复制本地价值判断的前提下联邦复用",
        ],
    }
