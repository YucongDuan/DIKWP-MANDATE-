# Decision 0001: MANDATE² as the missing transaction layer

Status: Accepted for prototype.

The existing ecosystem already contains semantic, forecasting, assurance, evidence, standards, resource and application modules. The missing cross-cutting object is a bounded public mandate connecting code to lawful and socially legitimate action. Therefore this project focuses on authorization and settlement rather than adding another vertical application.
