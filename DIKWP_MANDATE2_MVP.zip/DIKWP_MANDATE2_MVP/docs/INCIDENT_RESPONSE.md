# Incident Response

- S0: log and monitor.
- S1: service remediation within SLA.
- S2: pause affected component, notify and repair.
- S3: automatic hold, restore rights first, independent investigation and compensation review.
- S4: terminate the route, preserve evidence and initiate public emergency review.

The operator cannot be the sole investigator. Postmortems for S2+ are public by default, with privacy-preserving redactions where necessary.
