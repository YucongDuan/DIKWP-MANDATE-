# Rights and Representation

Affectedness, not platform ownership or funding size, determines the minimum voice that a group must receive. High-exposure groups require participation or co-authorization, not notification alone. Fundamental rights cannot be waived by a majority vote.

The protocol preserves a dissent packet containing objections, competing predictions, unresolved risks and trigger conditions. Dissent is not a defect to be averaged away; it is a future audit object.
