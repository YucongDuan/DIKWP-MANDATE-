# Field Node Playbook

A field node must create a local challenge dossier, map affected groups, declare legal authority, record semantic differences, obtain a local mandate, run an exit drill, and appoint an independent settlement panel. It may reuse code, tests and evidence from another node, but it cannot inherit that node's authorization.
