# Integration Map

- MESH²: observer-indexed semantic mesh and 25 transformations.
- PACT/P-Space: purpose, permissions and agent action assurance.
- ProofLedger: claim-evidence provenance.
- AION: forecasts, thresholds and settlement dates.
- EIR-Mesh: resource routing and flagship convergence.
- Coevolution Commons/Civicode: collective mission and institutional rules.
- ARK/GlobalDividend: social rights, resilience and value distribution.
- StandardForge/StewardOps/OriginMoat: conformance, stewardship and attribution.
- MANDATE²: public authorization, role separation, pilot, appeal, settlement and federation transaction layer.
