# Open Procurement Clauses

A public-action contract should require source and data portability, reproducible builds, SBOM, incident cooperation, open event records, milestone escrow, compensation reserve, continuity on vendor exit, no exclusive data lock-in, and the right to fork or replace the operator.

Payments should be tied to verifiable milestones, rights compliance and handover readiness—not only feature delivery or user growth.
