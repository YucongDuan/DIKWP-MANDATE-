# Public Action Protocol

## Principle

Public code is not public authority. A working repository becomes a legitimate public intervention only after it receives a bounded, revocable and reviewable mandate from the institutions and people whose rights, resources or environments are affected.

## Mandate levels

- M0 Concept: research and local sandbox only.
- M1 Inquiry: evidence collection and deliberation; no operational effects.
- M2 Shadow: replay or parallel evaluation; no adverse decision or resource allocation.
- M3 Bounded Pilot: real but voluntary, limited, time-bounded and reversible.
- M4 Limited Adoption: defined service scope after independent settlement.
- M5 Federated Replication: multiple local mandates and independent replications.
- M6 Commons Infrastructure: durable public-interest stewardship, portability and founder-independent maintenance.

Every mandate expires. Evidence may be inherited; authority may not.
