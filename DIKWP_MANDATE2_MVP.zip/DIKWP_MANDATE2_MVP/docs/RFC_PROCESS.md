# RFC Process

An RFC must state the problem, affected groups, DIKWP semantic changes, rights impact, alternatives including no action, evidence, security implications, migration, rollback, dissent and settlement plan. Accepted RFCs remain linked to implementation and test commits.
