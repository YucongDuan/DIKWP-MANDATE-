# Changelog

## 0.1.0 - 2026-07-17

- Initial public-action mandate protocol reference implementation.
- Added legitimacy hard gates, role separation, incident routing, federation passport, synthetic GitHub ecosystem audit, dashboard and tests.
