from __future__ import annotations

import json
import sys
import unittest
from datetime import date
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from dikwp_mandate2.ecosystem import audit_ecosystem
from dikwp_mandate2.ledger import HashLedger
from dikwp_mandate2.legitimacy import evaluate_dossier
from dikwp_mandate2.mesh import default_public_action_mesh, primitive_transformations, transformation_coverage
from dikwp_mandate2.protocol import compile_action_ticket, incident_response
from dikwp_mandate2.simulation import simulate


def load(name: str):
    return json.loads((ROOT / "examples" / name).read_text(encoding="utf-8"))


class MandateProtocolTests(unittest.TestCase):
    def test_all_25_dikwp_transformations_exist(self):
        self.assertEqual(len(primitive_transformations()), 25)
        audit = transformation_coverage(default_public_action_mesh())
        self.assertEqual(audit["coverage"], 1.0)
        self.assertTrue(audit["network_compatible"])

    def test_safe_bounded_pilot_is_m3_eligible(self):
        audit = evaluate_dossier(load("community_ai_transition_pilot.json"), today=date(2026, 7, 17))
        self.assertEqual(audit.decision, "PILOT_ELIGIBLE")
        self.assertEqual(audit.level_cap, "M3_BOUNDED_PILOT")
        self.assertFalse(audit.hard_failures)

    def test_ai_only_rights_denial_is_blocked(self):
        audit = evaluate_dossier(load("public_benefits_ai_triage_blocked.json"), today=date(2026, 7, 17))
        self.assertEqual(audit.decision, "BLOCK")
        self.assertIn("AUTOMATED_RIGHTS_DENIAL", audit.hard_failures)
        self.assertIn("AUTOMATED_COERCIVE_ACTION", audit.hard_failures)

    def test_proposer_cannot_self_settle(self):
        audit = evaluate_dossier(load("public_benefits_ai_triage_blocked.json"), today=date(2026, 7, 17))
        self.assertTrue(any(x.startswith("PROHIBITED_ROLE_OVERLAP") for x in audit.hard_failures))

    def test_no_action_baseline_is_required(self):
        audit = evaluate_dossier(load("public_benefits_ai_triage_blocked.json"), today=date(2026, 7, 17))
        self.assertIn("NO_ACTION_BASELINE_MISSING", audit.hard_failures)

    def test_shadow_dossier_does_not_silently_scale(self):
        audit = evaluate_dossier(load("agent_assurance_shadow.json"), today=date(2026, 7, 17))
        self.assertIn(audit.level_cap, {"M2_SHADOW", "M3_BOUNDED_PILOT"})
        self.assertNotIn(audit.decision, {"LIMITED_ADOPTION_ELIGIBLE", "FEDERATION_ELIGIBLE", "COMMONS_ELIGIBLE"})

    def test_action_ticket_only_for_m3_or_higher(self):
        ticket = compile_action_ticket(load("community_ai_transition_pilot.json"))
        self.assertEqual(ticket.state, "PROPOSED_NOT_ACTIVATED")
        with self.assertRaises(ValueError):
            compile_action_ticket(load("public_benefits_ai_triage_blocked.json"))

    def test_severe_incident_holds_and_restores_rights(self):
        response = incident_response("S3", load("community_ai_transition_pilot.json"))
        self.assertTrue(response["rights_first"])
        self.assertIn("AUTOMATIC_HOLD", response["required_action"])

    def test_hash_ledger_detects_tampering(self):
        ledger = HashLedger()
        ledger.append("A", {"x": 1})
        ledger.append("B", {"x": 2})
        self.assertTrue(ledger.verify())
        ledger.entries[0]["payload"]["x"] = 9
        self.assertFalse(ledger.verify())

    def test_ecosystem_audit_identifies_missing_transaction_layer(self):
        repos = json.loads((ROOT / "data" / "github_ecosystem_sample.json").read_text(encoding="utf-8"))
        audit = audit_ecosystem(repos)
        self.assertGreaterEqual(audit["sample_size"], 50)
        self.assertGreaterEqual(len(audit["missing_transaction_layer"]), 5)

    def test_synthetic_simulation_contains_four_strategies(self):
        result = simulate(800, 123)
        self.assertEqual(len(result["strategies"]), 4)
        self.assertTrue(result["synthetic"])

    def test_mandate_must_expire(self):
        dossier = load("community_ai_transition_pilot.json")
        dossier["mandate"]["expiry"] = ""
        audit = evaluate_dossier(dossier, today=date(2026, 7, 17))
        self.assertIn("MANDATE_HAS_NO_EXPIRY", audit.hard_failures)


if __name__ == "__main__":
    unittest.main()
